import React from 'react'
import SignUp from '../components/SignUp'

function SignUpPages() {
  return (
    <div>
      <h1>Sign Up</h1>
      <SignUp />
    </div>
  )
}

export default SignUpPages